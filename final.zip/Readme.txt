I created the basic 4 functions with a extra bonus function
The software that i'm using is flask+sqlite3+html
by entering app.py, the website is starting 